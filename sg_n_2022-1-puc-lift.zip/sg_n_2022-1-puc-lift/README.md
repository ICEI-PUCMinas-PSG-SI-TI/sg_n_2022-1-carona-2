[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7640327&assignment_repo_type=AssignmentRepo)
# PUC Lift
Chegando para ser seu novo método de transporte para e da faculdade, o PUC Lift trabalhará com um sistema de caronas. Por um preço camarada, pretendemos unir pessoas que moram perto umas das outras; quem tem carro com quem não tem, assim, dando a oportunidade de um transporte confortavel e aconchegante para os dois lados.

## Alunos integrantes da equipe

* Jean Machado - Líder
* João Artur - Product Owner
* Ícaro Arruda - Desenvolvimento
* Henrique Candelori - Desenvolvimento
* Miguel Sadi - Marketing

## Professores responsáveis

* João Caram Santos de Oliveira
* Marta Dias Moreira Noronha

## Informações uteis

* Link para o Trello do projeto - https://trello.com/b/HhOgxirK/puc-lift-team
* Link para a LOGO (jpeg) - https://imgur.com/a/EdJAzkT

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
