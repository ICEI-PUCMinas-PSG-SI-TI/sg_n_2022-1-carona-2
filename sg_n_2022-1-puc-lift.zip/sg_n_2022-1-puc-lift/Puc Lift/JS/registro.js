function cadastrar(){
    var nome = document.getElementById("name").value;
    var matricula = document.getElementById("matricula").value;
    var email = document.getElementById("email").value;
    var senha = document.getElementById("senha").value;
    var senha2 = document.getElementById("senha2").value;

    if(senha == senha2){
        localStorage.setItem('Name', nome);
        localStorage.setItem('Matricula', matricula);
        localStorage.setItem('Email', email);
        localStorage.setItem('Senha', senha);

        alert("Registrou");

        document.getElementById('name').value='';
        document.getElementById('matricula').value='';
        document.getElementById('email').value='';
        document.getElementById('senha').value='';
        document.getElementById('senha2').value='';
    } else{
        alert("Senhas não são iguais");

        document.getElementById('senha2').value='';
    }

}